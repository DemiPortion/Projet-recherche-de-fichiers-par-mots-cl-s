from fastapi.middleware.cors import CORSMiddleware
from fastapi import FastAPI
import psycopg
from psycopg.rows import dict_row

app = FastAPI(debug=True)

# Middleware pour CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=['http://127.0.0.1:5173', 'http://localhost:5173'],  # Correspond au port du frontend
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Route de test pour vérifier si l'API fonctionne
@app.get("/")
def read_root():
    return {"Hello": "World"}

# Route pour récupérer les utilisateurs
@app.get("/users")
def get_users():
    try:
        # Connexion à la base de données
        conn = psycopg.connect(
            "dbname='example' user='jojo' host='db' port=5432 password='haricow'",
            row_factory=dict_row  # Retourne les résultats sous forme de dictionnaires
        )
        with conn.cursor() as cur:
            # Exécution de la requête SQL
            cur.execute("SELECT id, name, email FROM users")
            users = cur.fetchall()  # Récupère tous les utilisateurs
    except Exception as e:
        # Gestion des erreurs
        return {"error": "Impossible de récupérer les utilisateurs", "details": str(e)}
    finally:
        if conn:
            conn.close()  # S'assure de fermer la connexion à la BDD
    
    # Retourne les utilisateurs
    return users

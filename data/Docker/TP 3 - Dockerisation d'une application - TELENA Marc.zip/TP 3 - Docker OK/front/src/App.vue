<script setup lang="ts">
import { ref } from 'vue'

// Définition de l'interface pour les utilisateurs
interface User {
  id: number;
  name: string;
  email: string;
}

// Initialisation du tableau d'utilisateurs avec le bon type
const users = ref<User[]>([])

// Fonction pour récupérer les utilisateurs depuis l'API
function getUsers() {
  fetch('http://127.0.0.1:8000/users') // URL du backend
    .then((response) => response.json() as Promise<User[]>) // Typage explicite des données reçues
    .then((data) => {
      users.value = data // Mise à jour du tableau d'utilisateurs
    })
    .catch((error) => {
      console.error('Erreur lors de la récupération des utilisateurs :', error)
    })
}
</script>

<template>
  <main>
    <button @click="getUsers">Afficher les utilisateurs</button>
    <ul>
      <!-- Boucle pour afficher les utilisateurs -->
      <li v-for="user in users" :key="user.id">
        {{ user.name }} - {{ user.email }}
      </li>
    </ul>
  </main>
</template>

<style scoped>
header {
  line-height: 1.5;
}

.logo {
  display: block;
  margin: 0 auto 2rem;
}

@media (min-width: 1024px) {
  header {
    display: flex;
    place-items: center;
    padding-right: calc(var(--section-gap) / 2);
  }

  .logo {
    margin: 0 2rem 0 0;
  }

  header .wrapper {
    display: flex;
    place-items: flex-start;
    flex-wrap: wrap;
  }
}
</style>

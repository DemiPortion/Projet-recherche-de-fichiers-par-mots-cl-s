
# **Dockerisation d'une Application Frontend, Backend et Base de Données**

## **Introduction**
Ce projet consiste à monter une stack Docker comprenant :
- Un **frontend** (Vue.js) pour afficher les utilisateurs.
- Un **backend** (FastAPI) pour gérer la communication avec la base de données.
- Une **base de données** PostgreSQL pour stocker les utilisateurs.

La stack est orchestrée à l'aide de `docker-compose`.

---

## **Prérequis**
Avant de démarrer, assurez-vous d'avoir les éléments suivants installés sur votre machine :
- **Docker** (version recommandée : 20.10 ou supérieure).
- **Docker Compose** (inclus dans Docker Desktop ou installable séparément).
- **Node.js** (version 18 ou supérieure) et **npm** (si vous souhaitez tester le frontend localement sans Docker).

### **Requirements Automatiques**
Les dépendances sont gérées automatiquement dans le projet :
- Backend :
  - Python 3.10
  - `requirements.txt` pour les dépendances Python (FastAPI, psycopg2, etc.).
- Frontend :
  - `package.json` gère les dépendances Vue.js.
- Base de données :
  - Image Docker officielle de PostgreSQL.

---

## **Installation et Lancement**


1. **Lancer le projet avec Docker Compose :**
   ```bash
   docker-compose up --build
   ```

2. **Accéder aux différents services :**
   - **Frontend** : [http://localhost:5173](http://localhost:5173)
   - **Backend** : [http://localhost:8000/users](http://localhost:8000/users)
   - **Base de données** : Accessible en interne par le backend via l'URL `postgresql://jojo:haricow@db:5432/example`.

---


## **Détails Techniques**

### **Frontend**
- **Technologie** : Vue.js
- **Port exposé** : `5173`
- **Dockerfile** :
  - Utilise une image Node.js pour installer les dépendances et construire l'application.
  - Utilise Nginx pour servir les fichiers statiques.

### **Backend**
- **Technologie** : FastAPI (Python)
- **Port exposé** : `8000`
- **Dépendances principales** :
  - `fastapi` : Framework web pour le backend.
  - `psycopg[binary]` : Pour communiquer avec PostgreSQL.

### **Base de Données**
- **Technologie** : PostgreSQL
- **Port exposé** : `5454` (accessible sur l'hôte)
- **Configuration** :
  - Nom de la base : `example`
  - Utilisateur : `jojo`
  - Mot de passe : `haricow`
- **Initialisation** :
  - Le fichier `init.sql` est automatiquement exécuté au démarrage pour créer la table `users` et insérer des données initiales.

---

## **Utilisation**

### **Frontend**
1. Lancez la stack Docker avec `docker-compose`.
2. Accédez à [http://localhost:5173](http://localhost:5173).
3. Cliquez sur "Afficher les utilisateurs" pour voir les données récupérées depuis le backend.

### **Backend**
1. Vérifiez que le backend est accessible sur [http://localhost:8000/users](http://localhost:8000/users).
2. L'API `/users` renvoie les utilisateurs sous forme de JSON.

### **Base de Données**
1. Connectez-vous à PostgreSQL (si nécessaire) :
   ```bash
   docker exec -it postgres_db psql -U jojo -d example
   ```
2. Vérifiez la table `users` :
   ```sql
   SELECT * FROM users;
   ```

---

## **Configuration et Personnalisation**
### **Ports**
Si vous souhaitez changer les ports par défaut :
- **Frontend** : Modifiez le `ports` dans le service `front` dans `docker-compose.yml`.
- **Backend** : Modifiez le `ports` dans le service `back` dans `docker-compose.yml`.
- **Base de données** : Modifiez le `ports` dans le service `db` dans `docker-compose.yml`.

### **Ajout d'Utilisateurs**
Pour ajouter des utilisateurs initiaux :
1. Modifiez le fichier `init.sql` avec des commandes SQL supplémentaires.
2. Supprimez les volumes Docker pour réinitialiser la base :
   ```bash
   docker-compose down -v
   docker-compose up --build
   ```

---

## **Dépannage**
### **Problèmes communs**
1. **Ports déjà utilisés** :
   - Changez les ports dans `docker-compose.yml`.
2. **La base de données n'est pas initialisée** :
   - Assurez-vous que le fichier `init.sql` est bien monté dans le service `db`.

---

## **Exemple de Résultat**
- API `/users` :
  ```json
  [
      {"id": 1, "name": "Example", "email": "example@outlook.fr"},
      {"id": 2, "name": "Marc TELENA", "email": "marc.telena@outlook.fr"}
  ]

  ```
- Affichage dans le frontend :
  ```
  Example - example@outlook.fr
  Marc TELENA - marc.telena@outlook.fr
  ```

---

## **Conclusion**
Cette stack Docker montre comment intégrer efficacement un frontend, un backend et une base de données conteneurisés. J'ai beaucoup appris en docker grace à ce TP !
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100)
);

INSERT INTO users (name, email) VALUES
('Utilisateur 1', 'utilisateur.1@outlook.fr'),
('Utilisateur 2', 'utilisateur.2@outlook.fr'),
('Utilisateur 3', 'utilisateur.3@outlook.fr'),
